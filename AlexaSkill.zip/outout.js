'use strict';

var outout = (function () {

    return {
        valz: function () {
            return 'meow';
        },
    };
})();
module.exports = outout;